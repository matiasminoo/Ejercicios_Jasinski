package CaraOSeca;
import Entidades.Jugador;
import Entidades.Maquina;
import Utiles.Utiles;

public class Main {
	
	static Maquina maquina = new Maquina();
	static Jugador jugador;
	
	static int min = 1;
	static int max = 2;
	
	public static void main(String [] args) {
		boolean error = false;	
		boolean fin = false;
		boolean saldoInsuficiente = false;
		int apuesta = 0;
		System.out.println("Decime tu nombre");
		String nombre = Utiles.s.nextLine();
		jugador = new Jugador(nombre);
		System.out.println(jugador.nombre + " Bienvenido al casino mas ilegal de Argentina!");
		
		do {
			apuesta = 3;
			if(jugador.monedas > 3) {	
				
			do {
				System.out.println("Saldo: " + jugador.monedas);
			System.out.println("Cuanto quiere apostar? (Apuesta minima 3 monedas) ");
			apuesta = Utiles.s.nextInt();
			if(apuesta > jugador.monedas) {
				System.out.println("No tiene suficientes monedas");
				saldoInsuficiente = true;
			}
			jugador.monedas -= apuesta;
			}while(saldoInsuficiente);
			System.out.println("Elija su lado \n");
			System.out.println("1. cara \n");
			System.out.println("2. ceca");
			int respuesta = Utiles.ingresarEntero(min,max);
			
			maquina.tirar();
			
			if(maquina.moneda.estado == 1) {
				System.out.println("Salio cara.");
			}else {
				System.out.println("Salio ceca.");
			}
			
			if(maquina.moneda.estado == respuesta) {
				System.out.println("Felicidades, ganaste!!!");
				jugador.monedas += apuesta * 2;
				System.out.println("Tenes un total de " + jugador.monedas + " monedas.");
				System.out.println("..................................");
			} else {
				System.out.println("Perdiste, mal ahi.");
				maquina.ganancia += apuesta;
				System.out.println("Saldo: " + jugador.monedas);
				System.out.println("..................................");
				
			} 
			if(jugador.monedas == 0) {
				System.out.println("Saldo insuficiente.");
				System.out.println("Cerrando juego...");
				break;
			}
			do {
				error = false;
				System.out.println("Queres seguir jugando? (Si/No).");
				String resp = Utiles.s.next();
				resp = resp.toUpperCase();
				if(!((resp.equals("SI")) || (resp.equals("NO")))) {
					System.out.println("Error. Pusiste cualquier cosa");
					error = true;
					Utiles.s.nextLine();
				}
				System.out.println("..................................");
				if(resp.equals("NO")) {
					System.out.println("Cerrando juego...");
					fin = true;
				}
				
			}while(error);
			} else {
				System.out.println("Apuesta minima 3 moneda, tu saldo es insuficiente.");
				fin = true;
			}
			
		}while(!fin);
		}
	}
	

	
