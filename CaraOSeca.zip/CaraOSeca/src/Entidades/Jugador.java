package Entidades;

public class Jugador {
	
	 public String nombre;
	 public int monedas = 10;
	 
	 public Jugador(String nombre) {
		 this.nombre = nombre;
	 }
	
}
