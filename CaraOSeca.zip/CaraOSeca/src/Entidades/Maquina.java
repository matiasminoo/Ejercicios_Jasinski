package Entidades;

import java.util.Random;

public class Maquina {
	
	public Moneda moneda = new Moneda();
	private Random r = new Random();
	public int ganancia = 0;
	
	public void tirar() {
		
		moneda.estado = r.nextInt(2) + 1;	
	}
	
	
}

