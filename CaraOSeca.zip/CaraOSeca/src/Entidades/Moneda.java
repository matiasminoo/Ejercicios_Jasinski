package Entidades;

public class Moneda {

		public int estado = 0;
}
