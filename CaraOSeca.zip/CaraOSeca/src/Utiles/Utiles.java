package Utiles;

import java.util.Scanner;

public class Utiles {
	
	public static Scanner s = new Scanner(System.in);

public static int ingresarEntero(int MIN, int MAX) {
	boolean error;
	int nro = 0;
	do {
		error = false;
		try { 
			nro = s.nextInt();
			if (nro < MIN || nro > MAX) {
				error = true;
				System.out.println("Error. El lado ingresado debe ser 0 (CARA) o 1 (CECA)");
				System.out.println("Ingrese de nuevo el lado");
			}
		} catch (Exception e) { 
			System.out.println("Error. Tipo de dato invalido");
			System.out.println("Ingrese otro numero");
			error = true;
		} finally {
			s.nextLine();
		}
	}while(error);
	
	return nro;
	
}
	


}

